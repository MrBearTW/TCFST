# -*- coding: utf-8 -*-
SETTINGS = {
    'DEBUG': True,
    'DOMAIN': {'test': {}}
}
