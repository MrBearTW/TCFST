# -*- coding: utf-8 -*-

URL_PREFIX = 'prefix'
API_VERSION = 'v1'
DOMAIN = {'contacts': {}}
