# -*- coding: utf-8 -*-

RESOURCE_METHODS = ['GET', 'POST']
URL_PREFIX = 'prefix'
DOMAIN = {'contacts': {}}
