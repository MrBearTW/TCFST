# -*- coding: utf-8 -*-

API_VERSION = 'v1'
DOMAIN = {'contacts': {}}
